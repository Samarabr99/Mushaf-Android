
package com.example.mushaf

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ScaleGestureDetector
import android.view.View
import android.widget.*
import android.os.ParcelFileDescriptor

class MainActivity : Activity() {
    private var descriptor: ParcelFileDescriptor? = null
    private var renderer: PdfRenderer? = null
    private var currentPage = 0
    private lateinit var pageImage: ZoomImageView
    private lateinit var pageLabel: TextView
    private lateinit var previousButton: Button
    private lateinit var nextButton: Button
    private lateinit var goButton: Button
    private lateinit var pageInput: EditText
    private val prefs by lazy { getSharedPreferences("mushaf", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildInterface()
        val saved = prefs.getString("pdf_uri", null)
        if (saved != null) openPdf(Uri.parse(saved)) else showEmpty()
    }

    private fun buildInterface() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(Color.rgb(245, 242, 232))
        }
        root.addView(TextView(this).apply {
            text = "المصحف الشريف"; textSize = 23f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(80, 48, 28))
        }, LinearLayout.LayoutParams(-1, dp(56)))

        pageImage = ZoomImageView(this).apply {
            onSwipe = { direction -> showPage(currentPage + direction) }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.rgb(235, 231, 218))
        }
        root.addView(pageImage, LinearLayout.LayoutParams(-1, 0, 1f))
        pageLabel = TextView(this).apply {
            text = "اختر ملف المصحف للبدء"; textSize = 16f
            gravity = Gravity.CENTER; setTextColor(Color.DKGRAY)
        }
        root.addView(pageLabel, LinearLayout.LayoutParams(-1, dp(38)))

        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER }
        previousButton = Button(this).apply { text = "السابق"; setOnClickListener { showPage(currentPage - 1) } }
        nextButton = Button(this).apply { text = "التالي"; setOnClickListener { showPage(currentPage + 1) } }
        nav.addView(previousButton, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(nextButton, LinearLayout.LayoutParams(0, dp(52), 1f))
        root.addView(nav)

        val controls = LinearLayout(this).apply { gravity = Gravity.CENTER }
        pageInput = EditText(this).apply {
            hint = "رقم الصفحة"; inputType = 2; gravity = Gravity.CENTER; setSingleLine(true)
        }
        goButton = Button(this).apply {
            text = "اذهب"
            setOnClickListener {
                val n = pageInput.text.toString().toIntOrNull()
                if (n != null) showPage(n - 1)
                else Toast.makeText(this@MainActivity, "أدخل رقم صفحة صحيحاً", Toast.LENGTH_SHORT).show()
            }
        }
        val open = Button(this).apply { text = "فتح المصحف PDF"; setOnClickListener { choosePdf() } }
        controls.addView(pageInput, LinearLayout.LayoutParams(0, dp(52), 1f))
        controls.addView(goButton)
        controls.addView(open)
        root.addView(controls)
        setContentView(root)
        updateButtons()
    }

    private fun choosePdf() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "application/pdf"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(i, 100)
    }

    @Deprecated("Legacy callback for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                prefs.edit().putString("pdf_uri", uri.toString()).putInt("last_page", 0).apply()
                openPdf(uri)
            } catch (e: Exception) {
                Toast.makeText(this, "تعذر فتح الملف", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun openPdf(uri: Uri) {
        closePdf()
        try {
            descriptor = contentResolver.openFileDescriptor(uri, "r")
            renderer = PdfRenderer(descriptor!!)
            currentPage = prefs.getInt("last_page", 0).coerceIn(0, renderer!!.pageCount - 1)
            showPage(currentPage)
        } catch (e: Exception) {
            closePdf(); showEmpty()
            Toast.makeText(this, "اختر ملف PDF صالحاً", Toast.LENGTH_LONG).show()
        }
    }

    private fun showPage(index: Int) {
        val pdf = renderer ?: return
        if (index !in 0 until pdf.pageCount) return
        val page = pdf.openPage(index)
        val width = (resources.displayMetrics.widthPixels * 2).coerceAtMost(1800)
        val height = (width * page.height.toFloat() / page.width).toInt().coerceAtMost(2600)
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        page.close()
        pageImage.setImageBitmap(bitmap)
        pageImage.resetZoom()
        currentPage = index
        pageLabel.text = "الصفحة ${index + 1} من ${pdf.pageCount}"
        pageInput.setText((index + 1).toString())
        prefs.edit().putInt("last_page", index).apply()
        updateButtons()
    }

    private fun showEmpty() {
        pageImage.setImageDrawable(null)
        pageLabel.text = "افتح ملف المصحف PDF من هاتفك"
        updateButtons()
    }

    private fun updateButtons() {
        val count = renderer?.pageCount ?: 0
        previousButton.isEnabled = count > 0 && currentPage > 0
        nextButton.isEnabled = count > 0 && currentPage < count - 1
        goButton.isEnabled = count > 0
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun closePdf() {
        try { renderer?.close() } catch (_: Exception) {}
        try { descriptor?.close() } catch (_: Exception) {}
        renderer = null; descriptor = null
    }
    override fun onDestroy() { closePdf(); super.onDestroy() }
}

class ZoomImageView(context: android.content.Context) : ImageView(context) {
    var onSwipe: ((Int) -> Unit)? = null
    private val gestures = android.view.GestureDetector(context,
        object : android.view.GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: android.view.MotionEvent) = true
            override fun onFling(e1: android.view.MotionEvent?, e2: android.view.MotionEvent,
                                 velocityX: Float, velocityY: Float): Boolean {
                if (e1 != null && kotlin.math.abs(e1.x - e2.x) > 90 &&
                    kotlin.math.abs(velocityX) > 250 && kotlin.math.abs(e1.x - e2.x) > kotlin.math.abs(e1.y - e2.y)) {
                    onSwipe?.invoke(if (e1.x > e2.x) 1 else -1)
                    return true
                }
                return false
            }
        })
    private var factor = 1f
    private val detector = ScaleGestureDetector(context,
        object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                factor = (factor * d.scaleFactor).coerceIn(1f, 4f)
                scaleX = factor; scaleY = factor
                return true
            }
        })
    fun resetZoom() { factor = 1f; scaleX = 1f; scaleY = 1f }
    override fun onTouchEvent(event: android.view.MotionEvent): Boolean {
        detector.onTouchEvent(event); gestures.onTouchEvent(event); return true
    }
}
